 public enum PatientType {
     AMBULATORIALE, RICOVERATO, EMERGENZA;
    }
